import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmovie',
  templateUrl: './adminmovie.component.html',
  styleUrls: ['./adminmovie.component.css']
})
export class AdminmovieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
