export class Ticket {
     id:any
    userid:any
    moviename:any
    movieid:any
    date:any
    showtime:any
    seats:any
    price:any
    banner:any
}
